﻿@echo off
chcp 65001 >nul
echo Abrindo o painel de extensoes do Google Chrome...
start chrome://extensions
echo.
echo ==============================================================
echo 1. Ative a chave 'Modo do desenvolvedor' (canto superior direito)
echo 2. Clique em 'Carregar sem compactacao'
echo 3. Selecione a pasta 'Extensao' que esta junto com este arquivo
echo ==============================================================
echo.
pause